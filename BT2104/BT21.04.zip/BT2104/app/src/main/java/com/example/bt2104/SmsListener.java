package com.example.bt2104;

public interface SmsListener {
    void onSmsReceived();
}